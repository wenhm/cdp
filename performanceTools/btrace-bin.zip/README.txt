BTrace is a safe, dynamic tracing system for the Java platform. BTrace project 
is hosted at http://kenai.com/projects/btrace. See also "docs" directory.
